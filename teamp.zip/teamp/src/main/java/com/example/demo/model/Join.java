package com.example.demo.model;

public class Join {
	private String id;
	private String pwd;
	private String kind;
	private String phonenum;
	private String acc;
	private String name;
	private String address;
	private String address1;
	private int frontregisnum;
	private int afterregisnum;
	private String nickname;
	private String resname;
	private int resnum;
	private String reskind;
	private String region;
	private String region1;
	private String resad;
	private String resphone;
	
	public String getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	public String getAcc() {
		return acc;
	}
	public void setAcc(String acc) {
		this.acc = acc;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAdd(String address) {
		this.address = address;
	}
	public int getFrontregisnum() {
		return frontregisnum;
	}
	public void setFrontregisnum(int frontregisnum) {
		this.frontregisnum = frontregisnum;
	}
	public int getAfterregisnum() {
		return afterregisnum;
	}
	public void setAfterregisnum(int afterregisnum) {
		this.afterregisnum = afterregisnum;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getResname() {
		return resname;
	}
	public void setResname(String resname) {
		this.resname = resname;
	}
	public int getResnum() {
		return resnum;
	}
	public void setResnum(int resnum) {
		this.resnum = resnum;
	}
	public String getReskind() {
		return reskind;
	}
	public void setReskind(String reskind) {
		this.reskind = reskind;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getResad() {
		return resad;
	}
	public void setResad(String resad) {
		this.resad = resad;
	}
	public String getResphone() {
		return resphone;
	}
	public void setResphone(String resphone) {
		this.resphone = resphone;
	}
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	public String getRegion1() {
		return region1;
	}
	public void setRegion1(String region1) {
		this.region1 = region1;
	}
	public void setAddress(String address) {
		this.address = address;
	}

}
