package com.example.demo.model;


public class Main {
   private int resnum; 
   private String region; 
   private String startdate; 
   private String reskind; 
   private String resname; 
   private int resphone; 
   private String grade; 
   private String resadd;
   private String ordererid;
   private String menuname;
   private String orderer;
   private String pickuptime;
   private String payment;
   private int totalprice;
   private String review;
   private String salecomple;
   private long resacc;
   private String average;
   
   

public String getOrdererid() {
	return ordererid;
}
public void setOrdererid(String ordererid) {
	this.ordererid = ordererid;
}
public String getMenuname() {
	return menuname;
}
public void setMenuname(String menuname) {
	this.menuname = menuname;
}
public String getOrderer() {
	return orderer;
}
public void setOrderer(String orderer) {
	this.orderer = orderer;
}
public String getPickuptime() {
	return pickuptime;
}
public void setPickuptime(String pickuptime) {
	this.pickuptime = pickuptime;
}
public String getPayment() {
	return payment;
}
public void setPayment(String payment) {
	this.payment = payment;
}
public int getTotalprice() {
	return totalprice;
}
public void setTotalprice(int totalprice) {
	this.totalprice = totalprice;
}
public String getReview() {
	return review;
}
public void setReview(String review) {
	this.review = review;
}
public String getSalecomple() {
	return salecomple;
}
public void setSalecomple(String salecomple) {
	this.salecomple = salecomple;
}
public int getResnum() {
	return resnum;
}
public void setResnum(int resnum) {
	this.resnum = resnum;
}
public String getRegion() {
	return region;
}
public void setRegion(String region) {
	this.region = region;
}
public String getStartdate() {
	return startdate;
}
public void setStartdate(String startdate) {
	this.startdate = startdate;
}
public String getReskind() {
	return reskind;
}
public void setReskind(String reskind) {
	this.reskind = reskind;
}
public String getResname() {
	return resname;
}
public void setResname(String resname) {
	this.resname = resname;
}
public int getResphone() {
	return resphone;
}
public void setResphone(int resphone) {
	this.resphone = resphone;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public String getResadd() {
	return resadd;
}
public void setResadd(String resadd) {
	this.resadd = resadd;
}
public long getResacc() {
	return resacc;
}
public void setResacc(long resacc) {
	this.resacc = resacc;
}
public String getAverage() {
	return average;
}
public void setAverage(String average) {
	this.average = average;
}

}