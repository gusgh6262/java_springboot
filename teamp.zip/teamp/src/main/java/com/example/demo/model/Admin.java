package com.example.demo.model;


public class Admin {
    private int noticenum;
	private String title;
    private int hits;
    private String nickname;
    private String startdate;
	private String boardtype;
	private String content;
	private String id;
	private String image;
    private String creatorid;
    private String img;
    private int boardnum;
    private String kind;
    private String phonenum; 
    private long acc; 
    private String name; 
    private String address; 
    private int frontregisnum; 
    private int afterregisnum;
    private String resname; 
    private int resnum; 
    private String reskind; 
    private String region; 
    private String resad; 
    private int resphone;
    
	public String getResname() {
		return resname;
	}
	public void setResname(String resname) {
		this.resname = resname;
	}
	public int getResnum() {
		return resnum;
	}
	public void setResnum(int resnum) {
		this.resnum = resnum;
	}
	public String getReskind() {
		return reskind;
	}
	public void setReskind(String reskind) {
		this.reskind = reskind;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getResad() {
		return resad;
	}
	public void setResad(String resad) {
		this.resad = resad;
	}
	public int getResphone() {
		return resphone;
	}
	public void setResphone(int resphone) {
		this.resphone = resphone;
	}
	public int getNoticenum() {
		return noticenum;
	}
	public void setNoticenum(int noticenum) {
		this.noticenum = noticenum;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getHits() {
		return hits;
	}
	public void setHits(int hits) {
		this.hits = hits;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getStartdate() {
		return startdate;
	}
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
	public String getBoardtype() {
		return boardtype;
	}
	public void setBoardtype(String boardtype) {
		this.boardtype = boardtype;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getCreatorid() {
		return creatorid;
	}
	public void setCreatorid(String creatorid) {
		this.creatorid = creatorid;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public int getBoardnum() {
		return boardnum;
	}
	public void setBoardnum(int boardnum) {
		this.boardnum = boardnum;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(String phonenum) {
		this.phonenum = phonenum;
	}
	public long getAcc() {
		return acc;
	}
	public void setAcc(long acc) {
		this.acc = acc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getFrontregisnum() {
		return frontregisnum;
	}
	public void setFrontregisnum(int frontregisnum) {
		this.frontregisnum = frontregisnum;
	}
	public int getAfterregisnum() {
		return afterregisnum;
	}
	public void setAfterregisnum(int afterregisnum) {
		this.afterregisnum = afterregisnum;
	} 
    

}