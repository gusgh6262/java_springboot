package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampleProject12Application {

	public static void main(String[] args) {
		SpringApplication.run(SampleProject12Application.class, args);
	}

}
